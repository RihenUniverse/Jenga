#include "Unitest/Unitest.h"

// Auto-main for unit tests
#define UNIT_TEST_AUTO_DEFINE_MAIN
#include "Unitest/AutoMain.h"
