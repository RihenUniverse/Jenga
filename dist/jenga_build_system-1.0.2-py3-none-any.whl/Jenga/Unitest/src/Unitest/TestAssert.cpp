#include "TestAssert.h"

namespace nkentseu
{
    namespace test
    {
        
    } // namespace test
    
} // namespace nkentseu
